<!DOCTYPE html>
<html>
<body>
<!-- The administrative section of the website. This is used in order to check directory listings and network connectivity  -->
	<h1>Admin Content Settings</h1>	
	<h2> Check for Internet Connection </h2>
	
	<form method = "get" action="ping.php">
		<input type="text" name="domain">
	</form>

	<h2> View file system </h2>
        <form method = "post" action="view.php">
        	<button>View directory</button>
        </form>


</body>
</html>


