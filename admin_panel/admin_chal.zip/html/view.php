<html>
<body>

<h2>Contents of the root directory</h2>
<?php

// Show the contents of the root directory	
exec('ls /',$output );

// For line being read from the file system
foreach($output as $line){
	
	echo $line;
	echo "\n";
}

?>
</body>
</html>
