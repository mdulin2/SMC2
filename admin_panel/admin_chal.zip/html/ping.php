<html>
<body>

Execution...
<?php

// Runs a ping in order to check for network connectivity
// Command looks like: 'ping <domain_name> -c 3' 
exec('ping '.$_GET["domain"]. ' -c 3',$output );

// For each line in the output
foreach($output as $line){
	
	echo $line;
	echo "\n";
}

?>
</body>
</html>
